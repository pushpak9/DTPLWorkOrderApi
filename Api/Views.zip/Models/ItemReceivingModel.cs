﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace IMSWebAPI.Models
{
    public class ItemReceivingModel
    {
        public string SiteCode { get; set; }
        public string ItemCode { get; set; }
        public string ItemDescription { get; set; }
        public string ItemBarcode { get; set; }
        public string PONo { get; set; }
        public string InvoiceNo { get; set; }
        public string Remarks { get; set; }
        public string ScannedBy { get; set; }
        public string Result { get; set; }
    }
}