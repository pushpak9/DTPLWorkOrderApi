﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace IMSWebAPI.Models
{
    public class UserMasterModel
    {
        public string SiteCode { get; set; }
        public string UserName { get; set; }
        public string UserID { get; set; }
        public string UserType { get; set; }
        public string Password { get; set; }
        public string EmailID { get; set; }
        public string PhoneNo { get; set; }
        public string Department { get; set; }
        public string CreatedBy { get; set; }
        public string Result { get; set; }
        public List<string> SaveRightsList { get; set; }
    }

    public class ModuleMasterModel
    {
        public string UserName { get; set; }
        public string UserID { get; set; }
        public string ModuleName { get; set; }
        public string HeaderName { get; set; }
        public string ControllerName { get; set; }
        public string ICon { get; set; }
        public string IndexPage { get; set; }
        public int MMID { get; set; }
        public string IsHeader { get; set; }
        public bool iStatus { get; set; }
        public string Result { get; set; }
    }
    public class DepartmentMasterModel
    {
        public List<string> List { get; set; }
        public string DepartmentName { get; set; }
        public string DepartmentValue { get; set; }
        public string Result { get; set; }

    }
    public class UserRights_Permission
    {
        public ICollection<UserRights> PermissionMaster { get; set; }
    }
    public class UserRights
    {
        public int URID { get; set; } = 0;
        public string UserID { get; set; } = string.Empty;
        public string ModuleName { get; set; } = string.Empty;
        public bool iStatus { get; set; } = false;
        public string RightsGivenBy { get; set; } = string.Empty;
        public DateTime RightsGivenOn { get; set; } = DateTime.UtcNow;
        public string Result { get; set; }

        public string SiteCode { get; set; }


    }
}