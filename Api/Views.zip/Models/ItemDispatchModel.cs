﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMSWebAPI.Models
{
    public class DispatchCustomerBind
    {
        public string CustCode { get; set; }
        public string CustomerName { get; set; }
    }
    public class ItemDispatchModel
    {
        public string SiteCode { get; set; }
        public string ItemCode { get; set; }
        public string CustomerName { get; set; } 

        public string ItemDescription { get; set; }
        public string ItemBarcode { get; set; }
        public string CustCode { get; set; }
        public string SONo { get; set; }
        public string SalesPerson { get; set; }
        public string UserID { get; set; }
        public string CourierDetails { get; set; }
        public string InvoiceNo { get; set; }
        public string Remarks { get; set; }
        public string DispatchedBy { get; set; }
        public string Result { get; set; }

    }
}