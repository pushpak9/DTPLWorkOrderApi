﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMSWebAPI.Models
{
    public class CustomerMasterModel
    {
        public string SiteCode { get; set; }
        public string CustCode { get; set; }
        public string CustName { get; set; }
        public string CustAddress { get; set; }
        public string PhNo { get; set; }
        public string EmailID { get; set; }
        public string CreatedBy { get; set; }
        public string Result { get; set; }
    }
}