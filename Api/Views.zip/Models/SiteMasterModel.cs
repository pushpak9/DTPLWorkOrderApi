﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMSWebAPI.Models
{
    public class SiteMasterModel
    {
        public string SiteCode { get; set; }
        public string SiteName { get; set; }
        public string SiteAddress { get; set; }
        public string CreatedBy { get; set; }
        public string Result { get; set; }
    }
}