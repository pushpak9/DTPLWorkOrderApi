﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IMSWebAPI.Models
{
    public class ItemMasterModel
    {
        public string SiteCode { get; set; }
        public string ItemCode { get; set; }
        public string ItemDesc { get; set; }
        public string ItemType { get; set; }
        public int ItemMinQty { get; set; }
        public int RemainingQty { get; set; }
        public string CreatedBy { get; set; }
        public string Brand { get; set; }

        public string Result { get; set; }
    }
}