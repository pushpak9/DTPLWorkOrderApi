﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IMSWebAPI.DataLayer
{
    public class DL_ItemMaster
    {
        Common obj = new Common();
        SqlCommand cmd = null;
        public DataTable dtGetItem(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEMMASTER";
                cmd.Parameters.AddWithValue("@type", "GETITEM");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtGetItemType(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEMMASTER";
                cmd.Parameters.AddWithValue("@type", "GETITEMTYPE");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtGetItemByID(string sItemCode,string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEMMASTER";
                cmd.Parameters.AddWithValue("@type", "GETITEMBYID");
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable SaveItem(ItemMasterModel request)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEMMASTER";
                cmd.Parameters.AddWithValue("@type", "SAVE");
                cmd.Parameters.AddWithValue("@ITEMCODE", request.ItemCode);
                cmd.Parameters.AddWithValue("@ITEMDESC", request.ItemDesc);
                cmd.Parameters.AddWithValue("@ITEMTYPE", request.ItemType);
                cmd.Parameters.AddWithValue("@ITEMMINQTY", request.ItemMinQty);
                cmd.Parameters.AddWithValue("@BRANDS", request.Brand);
                cmd.Parameters.AddWithValue("@CreatedBy", request.CreatedBy);
                cmd.Parameters.AddWithValue("@SITECODE", request.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable UpdateItem(ItemMasterModel request)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEMMASTER";
                cmd.Parameters.AddWithValue("@type", "UPDATE");
                cmd.Parameters.AddWithValue("@ITEMCODE", request.ItemCode);
                cmd.Parameters.AddWithValue("@ITEMDESC", request.ItemDesc);
                cmd.Parameters.AddWithValue("@ITEMTYPE", request.ItemType);
                cmd.Parameters.AddWithValue("@ITEMMINQTY", request.ItemMinQty);
                cmd.Parameters.AddWithValue("@BRANDS", request.Brand);
                cmd.Parameters.AddWithValue("@CreatedBy", request.CreatedBy);
                cmd.Parameters.AddWithValue("@SITECODE", request.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable DeleteItem(ItemMasterModel request)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEMMASTER";
                cmd.Parameters.AddWithValue("@type", "DELETEITEM");
                cmd.Parameters.AddWithValue("@ITEMCODE", request.ItemCode);
                cmd.Parameters.AddWithValue("@SITECODE", request.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
    }
}