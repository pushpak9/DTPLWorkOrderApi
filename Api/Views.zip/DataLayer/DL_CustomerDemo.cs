﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IMSWebAPI.DataLayer
{
    public class DL_CustomerDemo
    {
        Common obj = new Common();
        SqlCommand cmd = null;
        public DataTable dtBindItem(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEM_SENDFORDEMO";
                cmd.Parameters.AddWithValue("@type", "BINDITEM");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        public DataTable dtScanItemBarcode(ItemDispatchModel objModel)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEM_SENDFORDEMO";
                cmd.Parameters.AddWithValue("@type", "VALIDATEITEM");
                cmd.Parameters.AddWithValue("@ItemCode", objModel.ItemCode);
                cmd.Parameters.AddWithValue("@ItemBarcode", objModel.ItemBarcode);              
                cmd.Parameters.AddWithValue("@DEMOCUSTNAME", objModel.CustCode);
                cmd.Parameters.AddWithValue("@DEMOSALESPERSON", objModel.SalesPerson);                
                cmd.Parameters.AddWithValue("@ReceivedBy", objModel.DispatchedBy);
                cmd.Parameters.AddWithValue("@SITECODE", objModel.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        public DataTable dtReturnItem(ItemDispatchModel objModel)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEM_SENDFORDEMO";
                cmd.Parameters.AddWithValue("@type", "RETURNITEM");
                cmd.Parameters.AddWithValue("@ItemCode", objModel.ItemCode);
                cmd.Parameters.AddWithValue("@ItemBarcode", objModel.ItemBarcode);
                cmd.Parameters.AddWithValue("@DEMOCUSTNAME", objModel.CustCode);
                cmd.Parameters.AddWithValue("@DEMOSALESPERSON", objModel.SalesPerson);
                cmd.Parameters.AddWithValue("@ReceivedBy", objModel.DispatchedBy);
                cmd.Parameters.AddWithValue("@SITECODE", objModel.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
    }
}