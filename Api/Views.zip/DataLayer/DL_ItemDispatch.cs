﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;


namespace IMSWebAPI.DataLayer
{
    public class DL_ItemDispatch
    {
        Common obj = new Common();
        SqlCommand cmd = null;
        public DataTable dtBindItem(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEM_DISPATCH";
                cmd.Parameters.AddWithValue("@type", "BINDITEM");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtBindCustomer(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEM_DISPATCH";
                cmd.Parameters.AddWithValue("@type", "BINDCUSTOMER");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtScanItemBarcode(ItemDispatchModel objModel)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_ITEM_DISPATCH";
                cmd.Parameters.AddWithValue("@type", "VALIDATEITEM");
                cmd.Parameters.AddWithValue("@ItemCode", objModel.ItemCode);
                cmd.Parameters.AddWithValue("@ItemBarcode", objModel.ItemBarcode);
                cmd.Parameters.AddWithValue("@CUSTCODE", objModel.CustCode);
                cmd.Parameters.AddWithValue("@SONo", objModel.SONo);
                cmd.Parameters.AddWithValue("@SALESPERSON", objModel.SalesPerson);
                cmd.Parameters.AddWithValue("@COURIERDETAILS", objModel.CourierDetails);
                cmd.Parameters.AddWithValue("@InvoiceNo", objModel.InvoiceNo);
                cmd.Parameters.AddWithValue("@Remarks", objModel.Remarks);
                cmd.Parameters.AddWithValue("@DispatchedBy", objModel.DispatchedBy);
                cmd.Parameters.AddWithValue("@SITECODE", objModel.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
    }
}