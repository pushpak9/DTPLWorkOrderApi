﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IMSWebAPI.DataLayer
{
    public class DL_CustomerMaster
    {
        Common obj = new Common();
        SqlCommand cmd = null;
        public DataTable dtGetCustomer(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_CUSTOMERMASTER";
                cmd.Parameters.AddWithValue("@type", "GETCUSTOMER");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtCustomerByID(string sCustCode, string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_CUSTOMERMASTER";
                cmd.Parameters.AddWithValue("@type", "GETCUSTOMERBYID");
                cmd.Parameters.AddWithValue("@CustCode", sCustCode);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable SaveCustomer(CustomerMasterModel request)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_CUSTOMERMASTER";
                cmd.Parameters.AddWithValue("@type", "SAVE");
                cmd.Parameters.AddWithValue("@CustCode", request.CustCode);
                cmd.Parameters.AddWithValue("@CustName", request.CustName);
                cmd.Parameters.AddWithValue("@CustAddress", request.CustAddress);
                cmd.Parameters.AddWithValue("@EmailID", request.EmailID);
                cmd.Parameters.AddWithValue("@PhNo", request.PhNo);
                cmd.Parameters.AddWithValue("@CreatedBy", request.CreatedBy);
                cmd.Parameters.AddWithValue("@SITECODE", request.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable UpdateCustomer(CustomerMasterModel request)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_CUSTOMERMASTER";
                cmd.Parameters.AddWithValue("@type", "UPDATE");
                cmd.Parameters.AddWithValue("@CustCode", request.CustCode);
                cmd.Parameters.AddWithValue("@CustName", request.CustName);
                cmd.Parameters.AddWithValue("@CustAddress", request.CustAddress);
                cmd.Parameters.AddWithValue("@EmailID", request.EmailID);
                cmd.Parameters.AddWithValue("@PhNo", request.PhNo);
                cmd.Parameters.AddWithValue("@CreatedBy", request.CreatedBy);
                cmd.Parameters.AddWithValue("@SITECODE", request.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable DeleteCustomer(CustomerMasterModel request)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_CUSTOMERMASTER";
                cmd.Parameters.AddWithValue("@type", "DELETECUSTOMER");
                cmd.Parameters.AddWithValue("@CustCode", request.CustCode);
                cmd.Parameters.AddWithValue("@SITECODE", request.SiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
    }
}