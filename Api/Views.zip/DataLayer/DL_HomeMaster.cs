﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IMSWebAPI.DataLayer
{
    public class DL_HomeMaster
    {
        Common obj = new Common();
        SqlCommand cmd = null;
        public DataSet dtGetMasterRecord(string sSiteCode)
        {
            DataSet ds = new DataSet();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_HOME";
                cmd.Parameters.AddWithValue("@type", "GETMASTERDATA");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                ds = obj.ExecuteDataset(cmd);                
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return ds;
        }
        public DataTable dtDailyReceivingCount(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_HOME";
                cmd.Parameters.AddWithValue("@type", "COUNTDAILYRECEIVEDMATERIAL");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        public DataTable dtGetMaterilWiseCount(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_HOME";
                cmd.Parameters.AddWithValue("@type", "GETMATERIALWISECOUNT");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
    }
}