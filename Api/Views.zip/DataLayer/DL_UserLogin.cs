﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IMSWebAPI.DataLayer
{   
    public class DL_UserLogin
    {
        Common obj = new Common();
        SqlCommand cmd = null;
        public DataTable dtGetUserLogin(string sUserID,string sPassword,string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "LOGIN");
                cmd.Parameters.AddWithValue("@USERID", sUserID);
                cmd.Parameters.AddWithValue("@PASSWORD", sPassword);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable ChangePassword(string sUserID, string sPassword,string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "CHANGEPASSWORD");
                cmd.Parameters.AddWithValue("@USERID", sUserID);
                cmd.Parameters.AddWithValue("@PASSWORD", sPassword);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable GetUserForRights(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "GETUSERFORMODULE");
                cmd.Parameters.AddWithValue("@SiteCode", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable GetUserRights(string sUserID,string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "GETUSERRIGHTS");
                cmd.Parameters.AddWithValue("@USERID", sUserID);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }        
        public DataTable SaveUserRights(string sUserID,DataTable dtModuleList,string sSiteCode,string sRightsGivenBy)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "SAVEUSERRIGHTS");
                cmd.Parameters.AddWithValue("@USERID", sUserID);
                cmd.Parameters.AddWithValue("@details", dtModuleList);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                cmd.Parameters.AddWithValue("@RIGHTSGIVENBY", sRightsGivenBy);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }



        public DataTable GetModuleRights(string sUserID, string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "GETMODULEUSERRIGHTS");
                cmd.Parameters.AddWithValue("@USERID", sUserID);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable GetAllModuleList (string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_USERLOGIN";
                cmd.Parameters.AddWithValue("@type", "GETALLMODULES");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
    }
}