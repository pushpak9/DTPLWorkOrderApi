﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web;

namespace IMSWebAPI.DataLayer
{
    public class DL_Report
    {
        Common obj = new Common();
        SqlCommand cmd = null;

        #region Inventory Report
        public DataTable dtCurrentReceivingReport(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_INVENTORY_REPORT";
                cmd.Parameters.AddWithValue("@type", "GETCURRENTRECEIVINGREPORT");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtGetInventoryDetailsReport(string sSiteCode,
            DateTime FromDate, DateTime ToDate, string sItemCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_INVENTORY_REPORT";
                cmd.Parameters.AddWithValue("@type", "DETAILS");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                cmd.Parameters.AddWithValue("@FROMDATE", FromDate.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@TODATE", ToDate.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                Common.objLogs.WriteLog("Data Send : From Date : " + FromDate
                   + ", To Date :" + ToDate + ", Item Code : " + sItemCode
                   + ", Site Code :" + sSiteCode
                   , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        #endregion


        #region Receiving Report
        public DataTable dtGetAvailableInventoryReport_Daily(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_AVAILABLE_STOCK_REPORT";
                cmd.Parameters.AddWithValue("@type", "GETRECEIVINGREPORT");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtGetAvailableInventoryReport(string sSiteCode,
            DateTime FromDate, DateTime ToDate, string sItemCode, string sCompleteReport)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_AVAILABLE_STOCK_REPORT";
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                if (sCompleteReport == "1")
                {
                    cmd.Parameters.AddWithValue("@type", "GETCOMPLETEREPORTS");
                }
                else
                {
                    cmd.Parameters.AddWithValue("@type", "DETAILS");                    
                    cmd.Parameters.AddWithValue("@FROMDATE", FromDate.ToString("yyyy-MM-dd HH:mm:ss"));
                    cmd.Parameters.AddWithValue("@TODATE", ToDate.ToString("yyyy-MM-dd HH:mm:ss"));
                }
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                Common.objLogs.WriteLog("Data Send : From Date : " + FromDate
                   + ", To Date :" + ToDate + ", Item Code : " + sItemCode
                   + ", Site Code :" + sSiteCode
                   , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        #endregion

        #region Dispatch Report
        public DataTable dtGetDispatchInventoryReport_Daily(string sSiteCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_DISPATCH_STOCK_REPORT";
                cmd.Parameters.AddWithValue("@type", "GETDISPATCHREPORT");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtGetDispatchInventoryReport(string sSiteCode,
            DateTime FromDate, DateTime ToDate, string sItemCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_DISPATCH_STOCK_REPORT";
                cmd.Parameters.AddWithValue("@type", "DETAILS");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                cmd.Parameters.AddWithValue("@FROMDATE", FromDate.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@TODATE", ToDate.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                Common.objLogs.WriteLog("Data Send : From Date : " + FromDate
                   + ", To Date :" + ToDate + ", Item Code : " + sItemCode
                   + ", Site Code :" + sSiteCode
                   , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        #endregion

        public DataTable dtGetMinStockReport(string sSiteCode, string sItemCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_MIN_STOCK_REPORT";
                cmd.Parameters.AddWithValue("@type", "GETMINREPORT");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }


        #region Send to Demo Report
        public DataTable dtGetSendToDemoReportPending(string sSiteCode, string sItemCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "usp_sendTODemoReport";
                cmd.Parameters.AddWithValue("@type", "RECEIVINGPENDING");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }
        public DataTable dtSendToDemoReportAll(string sSiteCode,
            DateTime FromDate, DateTime ToDate, string sItemCode)
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "usp_sendTODemoReport";
                cmd.Parameters.AddWithValue("@type", "DETAILS");
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                cmd.Parameters.AddWithValue("@FROMDATE", FromDate.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@TODATE", ToDate.ToString("yyyy-MM-dd HH:mm:ss"));
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                Common.objLogs.WriteLog("Data Send : From Date : " + FromDate
                   + ", To Date :" + ToDate + ", Item Code : " + sItemCode
                   + ", Site Code :" + sSiteCode
                   , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }



        #endregion

        #region SummaryReport
        public DataTable dtGetSummaryReport(string sSiteCode,
         DateTime FromDate, DateTime ToDate, string sItemCode,
         string sReportType, string sCompleteReport
         )
        {
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "USP_SUMMARYREPORT";
                cmd.Parameters.AddWithValue("@type", sReportType);
                cmd.Parameters.AddWithValue("@SITECODE", sSiteCode);
                if (sCompleteReport == "0")
                {
                    cmd.Parameters.AddWithValue("@FROMDATE", FromDate.ToString("yyyy-MM-dd HH:mm:ss"));
                    cmd.Parameters.AddWithValue("@TODATE", ToDate.ToString("yyyy-MM-dd HH:mm:ss"));
                }
                cmd.Parameters.AddWithValue("@ITEMCODE", sItemCode);
                Common.objLogs.WriteLog("Data Send : From Date : " + FromDate
                    + ", To Date :" + ToDate + ", Item Code : " + sItemCode
                    + ", Site Code :" + sSiteCode
                    + ", Complete Data:" + sCompleteReport
                    + ", Report Type:" + sReportType
                    , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                DataSet ds = obj.ExecuteDataset(cmd);
                if (ds.Tables.Count > 0)
                {
                    dt = ds.Tables[0];
                    Common.objLogs.WriteLog(ds.Tables[0].Rows[0][0].ToString(),
                        DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                throw ex;
            }
            return dt;
        }

        #endregion
    }
}