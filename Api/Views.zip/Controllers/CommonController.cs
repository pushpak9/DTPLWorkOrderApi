﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class CommonController : ApiController
    {
        DataTable dt = new DataTable();
        DL_Common objCust = new DL_Common();
        [HttpGet]
        [Route("GetSalesPerson")]
        public IHttpActionResult GetSalesPerson(ItemDispatchModel obj)
        {
            List<ItemDispatchModel> objModel = new List<ItemDispatchModel>();
            try
            {
                dt = objCust.dtGetSalesPersonData(obj.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemDispatchModel()
                            {
                                UserID = Convert.ToString(dr["UserID"]),
                                SalesPerson = Convert.ToString(dr["UserName"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemDispatchModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GetCustData")]
        public IHttpActionResult GetCustData(ItemDispatchModel obj)
        {
            List<ItemDispatchModel> objModel = new List<ItemDispatchModel>();
            try
            {
                dt = objCust.dtBindCustomerMaster(obj.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemDispatchModel()
                            {
                                CustCode = Convert.ToString(dr["CUSTCODE"]),
                                CustomerName = Convert.ToString(dr["CUSTNAME"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemDispatchModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("BindReportItemCode")]
        public IHttpActionResult BindReportItemCode(ReportModel objReportModel)
        {
            List<ReportModel> objModel = new List<ReportModel>();
            try
            {
                dt = objCust.dtGetItem(objReportModel.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ReportModel()
                            {
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemDesc = Convert.ToString(dr["ItemDesc"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ReportModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }
    }
}