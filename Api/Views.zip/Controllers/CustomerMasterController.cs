﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;
using Newtonsoft.Json;
using System.Web.Helpers;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Web.Script.Serialization;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class CustomerMasterController : ApiController
    {
        DataTable dt = new DataTable();
        DL_CustomerMaster objCust = new DL_CustomerMaster();
        [HttpGet]
        [Route("GetCustomer")]
        public IHttpActionResult GetCustomer(CustomerMasterModel objCustModel)
        {
            List<CustomerMasterModel> objModel = new List<CustomerMasterModel>();
            try
            {
                dt = objCust.dtGetCustomer(objCustModel.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new CustomerMasterModel()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                CustCode = Convert.ToString(dr["CustCode"]),
                                CustName = Convert.ToString(dr["CustName"]),
                                CustAddress = Convert.ToString(dr["CustAddress"]),
                                EmailID = Convert.ToString(dr["EmailID"]),
                                PhNo = Convert.ToString(dr["PhNo"]),
                                CreatedBy = Convert.ToString(dr["CreatedBy"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new CustomerMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        public string DataTableToJSONWithJSONNet(DataTable table)
        {
            string JSONString = string.Empty;
            JSONString = JsonConvert.SerializeObject(table);
            return JSONString;
        }

        [HttpPost]
        [Route("GetCustomerByID")]
        public IHttpActionResult GetCustomerByID([FromBody] CustomerMasterModel request)
        {
            CustomerMasterModel objModel = new CustomerMasterModel();
            try
            {
                dt = objCust.dtCustomerByID(request.CustCode, request.SiteCode);
                foreach (DataRow dr in dt.Rows)
                {
                    objModel.SiteCode = Convert.ToString(dr["SiteCode"]);
                    objModel.CustCode = Convert.ToString(dr["CustCode"]);
                    objModel.CustName = Convert.ToString(dr["CustName"]);
                    objModel.CustAddress = Convert.ToString(dr["CustAddress"]);
                    objModel.EmailID = Convert.ToString(dr["EmailID"]);
                    objModel.PhNo = Convert.ToString(dr["PhNo"]);
                    objModel.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                    objModel.Result = "";
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("SaveCustomer")]
        public IHttpActionResult SaveCustomer(CustomerMasterModel request)
        {
            CustomerMasterModel objModel = new CustomerMasterModel();
            try
            {
                dt = objCust.SaveCustomer(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("UpdateCustomer")]
        public IHttpActionResult UpdateCustomer(CustomerMasterModel request)
        {
            CustomerMasterModel objModel = new CustomerMasterModel();
            try
            {
                dt = objCust.UpdateCustomer(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("DeleteCustomer")]
        public IHttpActionResult DeleteCustomer(CustomerMasterModel request)
        {
            CustomerMasterModel objModel = new CustomerMasterModel();
            try
            {
                dt = objCust.DeleteCustomer(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}