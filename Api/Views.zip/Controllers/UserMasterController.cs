﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class UserMasterController : ApiController
    {
        DataTable dt = new DataTable();
        DL_UserMaster objDLUserMaster = new DL_UserMaster();
        [HttpGet]
        [Route("BindDepartment")]
        public IHttpActionResult Bindepartment(UserMasterModel objDepartement)
        {
            List<DepartmentMasterModel> objModel = new List<DepartmentMasterModel>();
            try
            {
                dt = objDLUserMaster.dtBindDepartment(objDepartement.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new DepartmentMasterModel()
                            {
                                DepartmentName = Convert.ToString(dr["DepartementName"]),
                                DepartmentValue = Convert.ToString(dr["DepartementName"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new DepartmentMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);

        }

        [HttpGet]
        [Route("GetUser")]
        public IHttpActionResult BindUser(UserMasterModel request)
        {
            List<UserMasterModel> objModel = new List<UserMasterModel>();
            try
            {
                dt = objDLUserMaster.dtBindUser(request.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new UserMasterModel()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                UserID = Convert.ToString(dr["UserID"]),
                                UserName = Convert.ToString(dr["UserName"]),
                                UserType = Convert.ToString(dr["UserType"]),
                                Password = Convert.ToString(dr["Password"]),
                                EmailID = Convert.ToString(dr["EmailID"]),
                                PhoneNo = Convert.ToString(dr["PhNo"]),
                                Department = Convert.ToString(dr["Department"]),
                                CreatedBy = Convert.ToString(dr["CreatedBy"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new UserMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("GetUserByID")]
        public IHttpActionResult GetUserByID(UserMasterModel request)
        {
            UserMasterModel objModel = new UserMasterModel();
            try
            {
                dt = objDLUserMaster.dtGetUserByID(request.UserID, request.SiteCode);
                foreach (DataRow dr in dt.Rows)
                {
                    objModel.SiteCode = Convert.ToString(dr["SiteCode"]);
                    objModel.UserID = Convert.ToString(dr["UserID"]);
                    objModel.UserName = Convert.ToString(dr["UserName"]);
                    objModel.UserType = Convert.ToString(dr["UserType"]);
                    objModel.Password = Convert.ToString(dr["Password"]);
                    objModel.EmailID = Convert.ToString(dr["EmailID"]);
                    objModel.PhoneNo = Convert.ToString(dr["PhNo"]);
                    objModel.Department = Convert.ToString(dr["Department"]);
                    objModel.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                    objModel.Result = "";
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("SaveUser")]
        public IHttpActionResult saveUser(UserMasterModel request)
        {
            UserMasterModel objModel = new UserMasterModel();
            try
            {
                dt = objDLUserMaster.SaveUser(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("UpdateUser")]
        public IHttpActionResult UpdateUser(UserMasterModel request)
        {
            UserMasterModel objModel = new UserMasterModel();
            try
            {
                dt = objDLUserMaster.UpdateUser(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("DeleteUser")]
        public IHttpActionResult DeleteUser(UserMasterModel request)
        {
            UserMasterModel objModel = new UserMasterModel();
            try
            {
                dt = objDLUserMaster.DeleteUser(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}