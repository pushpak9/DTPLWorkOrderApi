﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;


namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class CustomerDemoController : ApiController
    {
        DataTable dt = new DataTable();
        DL_CustomerDemo objCust = new DL_CustomerDemo();
        [HttpGet]
        [Route("GetItemCustomerDemo")]
        public IHttpActionResult GetItem(ItemDispatchModel obj)
        {
            List<ItemDispatchModel> objModel = new List<ItemDispatchModel>();
            try
            {
                dt = objCust.dtBindItem(obj.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemDispatchModel()
                            {
                                ItemCode = Convert.ToString(dr["ITEMCODE"]),
                                ItemDescription = Convert.ToString(dr["ItemDesc"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemDispatchModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("SENDTODEMO")]
        public IHttpActionResult ScanItem(ItemDispatchModel request)
        {
            ItemDispatchModel objModel = new ItemDispatchModel();
            try
            {
                dt = objCust.dtScanItemBarcode(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("RETURNFROMDEMOCUSTOMER")]
        public IHttpActionResult RETURNFROMDEMOCUSTOMER(ItemDispatchModel request)
        {
            ItemDispatchModel objModel = new ItemDispatchModel();
            try
            {
                dt = objCust.dtReturnItem(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}