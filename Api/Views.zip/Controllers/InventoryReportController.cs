﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class InventoryReportController : ApiController
    {
        DataTable dt = new DataTable();
        DL_Report objDL_Report = new DL_Report();

        #region Inventory Report

        [HttpGet]
        [Route("GetCurrentInventoryReport")]
        public IHttpActionResult GetCurrentInventoryReport(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtCurrentReceivingReport(objReportModel.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                PONO = Convert.ToString(dr["PONo"]),
                                InvoiceNo = Convert.ToString(dr["InvoiceNo"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                Remarks = Convert.ToString(dr["Remarks"]),
                                ItemStatus = Convert.ToString(dr["ItemStatus"]),
                                ReceivedBy = Convert.ToString(dr["ReceivedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["ReceivedOn"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GetInventoryReport")]
        public IHttpActionResult GetInventoryReport(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {

                dt = objDL_Report.dtGetInventoryDetailsReport(objReportModel.SiteCode
                    , objReportModel.FromDate, objReportModel.ToDate, objReportModel.ItemCode);
                Common.objLogs.WriteLog("Data Received : No Of Rows : " + dt.Rows.Count.ToString()
               , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                PONO = Convert.ToString(dr["PONo"]),
                                InvoiceNo = Convert.ToString(dr["InvoiceNo"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                Remarks = Convert.ToString(dr["Remarks"]),
                                ItemStatus = Convert.ToString(dr["ItemStatus"]),
                                ReceivedBy = Convert.ToString(dr["ReceivedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["ReceivedOn"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        #endregion

        #region Receiving Report

        [HttpGet]
        [Route("GetAvaliableReceivingReport")]
        public IHttpActionResult GetAvaliableReceivingReport(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtGetAvailableInventoryReport_Daily(objReportModel.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                PONO = Convert.ToString(dr["PONo"]),
                                InvoiceNo = Convert.ToString(dr["InvoiceNo"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                Remarks = Convert.ToString(dr["Remarks"]),
                                ItemStatus = Convert.ToString(dr["ItemStatus"]),
                                ReceivedBy = Convert.ToString(dr["ReceivedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["ReceivedOn"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GetReceivingReport")]
        public IHttpActionResult GetAvailableInventoryReport(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtGetAvailableInventoryReport(objReportModel.SiteCode
                    , objReportModel.FromDate, objReportModel.ToDate, objReportModel.ItemCode
                    , objReportModel.CompleteReport
                    );
                Common.objLogs.WriteLog("Data Received : No Of Rows : " + dt.Rows.Count.ToString()
               , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                PONO = Convert.ToString(dr["PONo"]),
                                InvoiceNo = Convert.ToString(dr["InvoiceNo"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                Remarks = Convert.ToString(dr["Remarks"]),
                                ItemStatus = Convert.ToString(dr["ItemStatus"]),
                                ReceivedBy = Convert.ToString(dr["ReceivedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["ReceivedOn"])
                            }).ToList();

            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        #endregion

        #region Dispatch Report

        [HttpGet]
        [Route("GetDispatchReportDaily")]
        public IHttpActionResult GetDispatchReportDaily(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtGetDispatchInventoryReport_Daily(objReportModel.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                CustName = Convert.ToString(dr["CustCode"]),
                                SONo = Convert.ToString(dr["SONo"]),
                                InvoiceNo = Convert.ToString(dr["InvoiceNo"]),
                                SalesPerson = Convert.ToString(dr["SalesPerson"]),
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                Remarks = Convert.ToString(dr["Remarks"]),
                                CourierDetails = Convert.ToString(dr["CourierDetails"]),
                                ReceivedBy = Convert.ToString(dr["ReceivedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["ReceivedOn"]),
                                DispatchedBy = Convert.ToString(dr["DispatchedBy"]),
                                DispatchedOn = Convert.ToDateTime(dr["DispatchedOn"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("dtGetDispatchInventoryReport")]
        public IHttpActionResult dtGetDispatchInventoryReport(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtGetDispatchInventoryReport(objReportModel.SiteCode
                    , objReportModel.FromDate, objReportModel.ToDate, objReportModel.ItemCode);
                Common.objLogs.WriteLog("Data Received : No Of Rows : " + dt.Rows.Count.ToString()
               , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                CustName = Convert.ToString(dr["CustCode"]),
                                SONo = Convert.ToString(dr["SONo"]),
                                InvoiceNo = Convert.ToString(dr["InvoiceNo"]),
                                SalesPerson = Convert.ToString(dr["SalesPerson"]),
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                Remarks = Convert.ToString(dr["Remarks"]),
                                CourierDetails = Convert.ToString(dr["CourierDetails"]),
                                ReceivedBy = Convert.ToString(dr["ReceivedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["ReceivedOn"]),
                                DispatchedBy = Convert.ToString(dr["DispatchedBy"]),
                                DispatchedOn = Convert.ToDateTime(dr["DispatchedOn"])
                            }).ToList();

            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        #endregion

        #region MinStockReport
        [HttpGet]
        [Route("dtGetMinStockReport")]
        public IHttpActionResult dtGetMinStockReport(ReportModel objReportModel)
        {
            List<ItemMasterModel> objModel = new List<ItemMasterModel>();
            try
            {
                dt = objDL_Report.dtGetMinStockReport(objReportModel.SiteCode, objReportModel.ItemCode);
                Common.objLogs.WriteLog("Data Received : No Of Rows : " + dt.Rows.Count.ToString()
               , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                objModel = (from DataRow dr in dt.Rows
                            select new ItemMasterModel()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemDesc = Convert.ToString(dr["ItemDesc"]),
                                ItemType = Convert.ToString(dr["ItemType"]),
                                Brand = Convert.ToString(dr["Brand"]),
                                ItemMinQty = Convert.ToInt32(dr["ItemMinQty"]),
                                RemainingQty = Convert.ToInt32(dr["RemainingQty"])
                            }).ToList();

            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        #endregion

        #region Send To Demo Report

        [HttpGet]
        [Route("GetSendToDemoReportPending")]
        public IHttpActionResult GetSendToDemoReportPending(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtGetSendToDemoReportPending(objReportModel.SiteCode, objReportModel.ItemCode);
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                CustName = Convert.ToString(dr["Customer"]),
                                SalesPerson = Convert.ToString(dr["SalesPerson"]),
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                ReceivedBy = Convert.ToString(dr["InsertedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["InsertedOn"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GetSendToDemoReportALL")]
        public IHttpActionResult GetSendToDemoReportALL(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtSendToDemoReportAll(objReportModel.SiteCode
                    , objReportModel.FromDate, objReportModel.ToDate, objReportModel.ItemCode);
                Common.objLogs.WriteLog("Data Received : No Of Rows : " + dt.Rows.Count.ToString()
               , DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                CustName = Convert.ToString(dr["Customer"]),
                                SalesPerson = Convert.ToString(dr["SalesPerson"]),
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"]),
                                ReceivedBy = Convert.ToString(dr["InsertedBy"]),
                                ReceivedOn = Convert.ToDateTime(dr["InsertedOn"])
                            }).ToList();

            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }


        #endregion

        #region SummaryReport
        [HttpGet]
        [Route("GETSUMMARYREPORT")]
        public IHttpActionResult GETSUMMARYREPORT(ReportModel objReportModel)
        {
            List<InventoryReceivingReport> objModel = new List<InventoryReceivingReport>();
            try
            {
                dt = objDL_Report.dtGetSummaryReport(objReportModel.SiteCode
                    , objReportModel.FromDate, objReportModel.ToDate, objReportModel.ItemCode,
                    objReportModel.ReportType,objReportModel.CompleteReport
                    );
                objModel = (from DataRow dr in dt.Rows
                            select new InventoryReceivingReport()
                            {
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                ItemBarcode = Convert.ToString(dr["ItemBarcode"])
                            }).ToList();


            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new InventoryReceivingReport
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        #endregion
    }
}