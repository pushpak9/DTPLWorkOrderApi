﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using Newtonsoft.Json;
using IMSWebAPI.DataLayer;
using System.Linq;
using System.ComponentModel;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class UserLoginController : ApiController
    {
        DataTable dt = new DataTable();
        DL_UserLogin objdlUserLogin = new DL_UserLogin();
        [HttpPost]
        [Route("Login")]
        public IHttpActionResult UserLogin(UserMasterModel objLogin)
        {
            Common.objLogs.WriteLog("Login Method Called for user ID : " + objLogin.UserID, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
            UserMasterModel UserMasterModel1 = new UserMasterModel();
            try
            {
                dt = objdlUserLogin.dtGetUserLogin(objLogin.UserID, objLogin.Password, objLogin.SiteCode);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        UserMasterModel1.Result = Convert.ToString(dr["ERRORMSG"]);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                UserMasterModel1.Result = ex.Message;
            }
            return Json(UserMasterModel1);
        }
        

        [HttpGet]
        [Route("GETRIGHTSUSER")]
        public IHttpActionResult GETRIGHTSUSER(UserMasterModel objLogin)
        {
            List<ModuleMasterModel> obj = new List<ModuleMasterModel>();
            string sResult = string.Empty;
            try
            {
                dt = objdlUserLogin.GetUserForRights(objLogin.SiteCode);
                if (dt.Rows.Count > 0)
                {
                    obj = (from DataRow dr in dt.Rows
                           select new ModuleMasterModel()
                           {
                               UserID = Convert.ToString(dr["UserID"]),
                               UserName = Convert.ToString(dr["UserName"]),
                           }).ToList();
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                obj.Add(
                        new ModuleMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(obj);
        }

        [HttpGet]
        [Route("ChangePassword")]
        public IHttpActionResult ChangePassword(UserMasterModel objLogin)
        {
            List<UserMasterModel> obj = new List<UserMasterModel>();
            string sResult = string.Empty;
            try
            {
                dt = objdlUserLogin.ChangePassword(objLogin.UserID, objLogin.Password, objLogin.SiteCode);
                sResult = JsonConvert.SerializeObject(dt);
                obj.Add(
                        new UserMasterModel
                        {
                            Result = sResult
                        });
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                obj.Add(
                        new UserMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(obj);
        }

        [HttpGet]
        [Route("GetRights")]
        public IHttpActionResult GetRights(UserMasterModel objLogin)
        {
            List<ModuleMasterModel> obj = new List<ModuleMasterModel>();
            string sResult = string.Empty;
            try
            {
                dt = objdlUserLogin.GetUserRights(objLogin.UserID, objLogin.SiteCode);
                obj = (from DataRow dr in dt.Rows
                       select new ModuleMasterModel()
                       {
                           ModuleName = Convert.ToString(dr["ModuleName"]),
                           iStatus = Convert.ToBoolean(dr["Status"])
                       }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                obj.Add(
                        new ModuleMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(obj);
        }
        

        [HttpGet]
        [Route("SaveRights")]
        public IHttpActionResult SaveRights(UserRights_Permission objLogin)
        {
            UserMasterModel UserMasterModel1 = new UserMasterModel();
            string sResult = string.Empty;
            string sUserID = string.Empty;
            string sSiteCode = string.Empty;
            string sRightsGivenBy = string.Empty;
            DataTable dtRights = new DataTable();
            try
            {
                DataTable dtRightsData = ListToDatatable.ToDataTable1(objLogin.PermissionMaster); //(DataTable)JsonConvert.DeserializeObject(objLogin.Permission, (typeof(DataTable)));
                if (dtRightsData.Rows.Count > 0)
                {
                    sUserID = dtRightsData.Rows[0][1].ToString();
                    sSiteCode = dtRightsData.Rows[0]["SiteCode"].ToString();
                    sRightsGivenBy = dtRightsData.Rows[0]["RightsGivenBy"].ToString();
                    string[] selectedColumns = new[] { "ModuleName", "iStatus" };
                    dtRights = new DataView(dtRightsData).ToTable(false, selectedColumns);
                    Common.objLogs.WriteLog("RightsData : " + dtRightsData.Rows[0][0].ToString(), DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                }
                dt = objdlUserLogin.SaveUserRights(sUserID, dtRights, sSiteCode, sRightsGivenBy);
                if (dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        UserMasterModel1.Result = Convert.ToString(dt.Rows[0][0].ToString());
                    }
                }
                else
                {
                    UserMasterModel1.Result = "ERROR~Unable to save data, Please try again";
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                UserMasterModel1.Result = "ERROR~" + ex.Message;
            }
            return Json(UserMasterModel1);
        }

        [HttpGet]
        [Route("GetModuleRights")]
        public IHttpActionResult GetModuleRights(UserMasterModel objLogin)
        {
            List<ModuleMasterModel> obj = new List<ModuleMasterModel>();
            string sResult = string.Empty;
            try
            {
                dt = objdlUserLogin.GetModuleRights(objLogin.UserID, objLogin.SiteCode);
                obj = (from DataRow dr in dt.Rows
                       select new ModuleMasterModel()
                       {                          
                           ModuleName = Convert.ToString(dr["ModuleName"]),
                           HeaderName = Convert.ToString(dr["HeaderName"]),
                           ControllerName = Convert.ToString(dr["ControllerName"]),
                           ICon = Convert.ToString(dr["ICon"]),
                           IndexPage = Convert.ToString(dr["IndexPage"]),
                           IsHeader = Convert.ToString(dr["IsHeader"])
                       }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                obj.Add(
                        new ModuleMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(obj);
        }
        
        
        [HttpGet]
        [Route("GetAllModuleList")]
        public IHttpActionResult GetAllModules (UserMasterModel objLogin)
        {
            List<ModuleMasterModel> obj = new List<ModuleMasterModel>();
            string sResult = string.Empty;
            try
            {
                dt = objdlUserLogin.GetAllModuleList(objLogin.SiteCode);
                obj = (from DataRow dr in dt.Rows
                       select new ModuleMasterModel()
                       {
                           ModuleName = Convert.ToString(dr["ModuleName"]),
                           HeaderName = Convert.ToString(dr["HeaderName"]),
                           ControllerName = Convert.ToString(dr["ControllerName"]),
                           ICon = Convert.ToString(dr["ICon"]),
                           IndexPage = Convert.ToString(dr["IndexPage"]),
                           IsHeader = Convert.ToString(dr["IsHeader"])
                       }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                obj.Add(
                        new ModuleMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(obj);
        }

    }
    
    public static class ListToDatatable
    {
        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection properties =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);
            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }
        public static DataTable ToDataTable1<T>(this IEnumerable<T> collection)
        {
            DataTable dt = new DataTable();
            Type t = typeof(T);
            PropertyInfo[] pia = t.GetProperties();
            object temp;
            DataRow dr;

            for (int i = 0; i < pia.Length; i++)
            {
                dt.Columns.Add(pia[i].Name, Nullable.GetUnderlyingType(pia[i].PropertyType) ?? pia[i].PropertyType);
                dt.Columns[i].AllowDBNull = true;
            }

            //Populate the table
            foreach (T item in collection)
            {
                dr = dt.NewRow();
                dr.BeginEdit();

                for (int i = 0; i < pia.Length; i++)
                {
                    temp = pia[i].GetValue(item, null);
                    if (temp == null || (temp.GetType().Name == "Char" && ((char)temp).Equals('\0')))
                    {
                        dr[pia[i].Name] = (object)DBNull.Value;
                    }
                    else
                    {
                        dr[pia[i].Name] = temp;
                    }
                }

                dr.EndEdit();
                dt.Rows.Add(dr);
            }
            return dt;
        }
    }
}
