﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;
namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class HomeMasterController : ApiController
    {
        DataTable dt = new DataTable();
        DL_HomeMaster objCust = new DL_HomeMaster();
        [HttpPost]
        [Route("GETMASTERCOUNT")]
        public IHttpActionResult GetMasterCount(MasterModelData obj)
        {
            MasterModelData objModel = new MasterModelData();
            try
            {
                DataSet dt = objCust.dtGetMasterRecord(obj.SiteCode);
                if (dt.Tables.Count > 0)
                {
                    objModel.CUST_COUNTRECORD = 0;
                    objModel.ITEM_COUNTRECORD = 0;
                    objModel.ITEM_REC_COUNTRECORD = 0;
                    if (dt.Tables[0].Rows.Count > 0)
                    {
                        if (dt.Tables[0].Rows[0][0].ToString().Length > 0)
                        {
                            objModel.CUST_COUNTRECORD = Convert.ToInt32(dt.Tables[0].Rows[0][0].ToString());
                        }
                    }
                    if (dt.Tables[1].Rows.Count > 0)
                    {
                        if (dt.Tables[1].Rows[0][0].ToString().Length > 0)
                        {
                            objModel.ITEM_COUNTRECORD = Convert.ToInt32(dt.Tables[1].Rows[0][0].ToString());
                        }
                    }
                    if (dt.Tables[2].Rows.Count > 0)
                    {
                        if (dt.Tables[2].Rows[0][0].ToString().Length > 0)
                        {
                            objModel.ITEM_REC_COUNTRECORD = Convert.ToInt32(dt.Tables[2].Rows[0][0].ToString());
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("GETDAILYRECEIVINGCOUNT")]
        public IHttpActionResult GETDAILYRECEIVINGCOUNT(MasterModelData obj)
        {
            MasterModelData objModel = new MasterModelData();
            try
            {
                dt = objCust.dtDailyReceivingCount(obj.SiteCode);
                objModel.COUNTRECORD = 0;
                if (dt.Rows.Count > 0)
                {
                    if (dt.Rows[0][0].ToString().Length > 0)
                    {
                        objModel.COUNTRECORD = Convert.ToInt32(dt.Rows[0][0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GETMATERILWISECOUNT")]
        public IHttpActionResult GETMATERILWISECOUNT(MasterModelData obj)
        {
            List<MasterModelData> objModel = new List<MasterModelData>();
            try
            {
                dt = objCust.dtGetMaterilWiseCount(obj.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new MasterModelData()
                            {
                                MatType = Convert.ToString(dr["MAT_TYPE"]),
                                ItemCode = Convert.ToString(dr["ITEMCODE"]),
                                COUNTRECORD = Convert.ToInt32(dr["ITEM_REC_COUNTRECORD"].ToString())
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                       new MasterModelData
                       {
                           Result = ex.Message
                       });
            }
            return Json(objModel);
        }
    }
}