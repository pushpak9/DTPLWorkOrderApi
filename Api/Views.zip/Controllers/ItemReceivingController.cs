﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class ItemReceivingController : ApiController
    {
        DataTable dt = new DataTable();
        DL_ItemReceiving objCust = new DL_ItemReceiving();
        [HttpGet]
        [Route("BindItemReceiving")]
        public IHttpActionResult GetItem(ItemReceivingModel request)
        {
            List<ItemReceivingModel> objModel = new List<ItemReceivingModel>();
            try
            {
                dt = objCust.dtBindItem(request.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemReceivingModel()
                            {
                                ItemCode = Convert.ToString(dr["ITEMCODE"]),
                                ItemDescription = Convert.ToString(dr["ItemDesc"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemReceivingModel
                        {
                            Result = ex.Message
                        });                
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("ScanItemReceiving")]
        public IHttpActionResult ScanItem(ItemReceivingModel request)
        {
            ItemReceivingModel objModel = new ItemReceivingModel();
            try
            {
                dt = objCust.dtScanItemBarcode(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}
