﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using IMSWebAPI.DataLayer;
using System.Linq;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class ItemDispatchController : ApiController
    {
        DataTable dt = new DataTable();
        DL_ItemDispatch objCust = new DL_ItemDispatch();
        [HttpGet]
        [Route("GetItemDispatch")]
        public IHttpActionResult GetItem(ItemDispatchModel obj)
        {
            List<ItemDispatchModel> objModel = new List<ItemDispatchModel>();
            try
            {
                dt = objCust.dtBindItem(obj.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemDispatchModel()
                            {
                                ItemCode = Convert.ToString(dr["ITEMCODE"]),
                                ItemDescription = Convert.ToString(dr["ItemDesc"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemDispatchModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GETDISPATCHCUSTOMER")]
        public IHttpActionResult GETDISPATCHCUSTOMER(ItemDispatchModel obj)
        {
            List<DispatchCustomerBind> objModel = new List<DispatchCustomerBind>();
            try
            {
                dt = objCust.dtBindCustomer(obj.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new DispatchCustomerBind()
                            {
                                CustCode = Convert.ToString(dr["CUSTCODE"]),
                                CustomerName = Convert.ToString(dr["CUSTNAME"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new DispatchCustomerBind
                        {
                            CustCode = ex.Message,
                            CustomerName = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("ScanItemDispatch")]
        public IHttpActionResult ScanItem(ItemDispatchModel request)
        {
            ItemDispatchModel objModel = new ItemDispatchModel();
            try
            {
                dt = objCust.dtScanItemBarcode(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}
