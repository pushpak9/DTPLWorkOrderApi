﻿using IMSWebAPI.DataLayer;
using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Web.Http;


namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class SiteMasterController : ApiController
    {
        DataTable dt = new DataTable();
        DL_SiteMaster objDL = new DL_SiteMaster();
        [HttpGet]
        [Route("GetSite")]
        public IHttpActionResult GetSite(SiteMasterModel objSiteModel)
        {
            List<SiteMasterModel> objModel = new List<SiteMasterModel>();
            try
            {
                dt = objDL.dtGetSite();
                objModel = (from DataRow dr in dt.Rows
                            select new SiteMasterModel()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                SiteName = Convert.ToString(dr["SiteName"]),
                                SiteAddress = Convert.ToString(dr["SiteAddress"]),
                                CreatedBy = Convert.ToString(dr["CreatedBy"])
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new SiteMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("GetSiteByID")]
        public IHttpActionResult GetSiteByID(SiteMasterModel request)
        {
            SiteMasterModel objModel = new SiteMasterModel();
            try
            {
                dt = objDL.dtSiteByID(request.SiteCode);
                foreach (DataRow dr in dt.Rows)
                {
                    objModel.SiteCode = Convert.ToString(dr["SiteCode"]);
                    objModel.SiteName = Convert.ToString(dr["SiteName"]);
                    objModel.SiteAddress = Convert.ToString(dr["SiteAddress"]);
                    objModel.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                    objModel.Result = "";
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("SaveSite")]
        public IHttpActionResult SaveSite(SiteMasterModel request)
        {
            SiteMasterModel objModel = new SiteMasterModel();
            try
            {
                Common.objLogs.WriteLog("Save Site Data for Site Code :" + request.SiteCode, DTPLLogs.DTPLLogsWrite.LogType.Information, MethodBase.GetCurrentMethod());
                dt = objDL.SaveSite(request);
                Common.objLogs.WriteLog("Save Site Result :" + dt.Rows[0][0].ToString(), DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("UpdateSite")]
        public IHttpActionResult UpdateSite(SiteMasterModel request)
        {
            SiteMasterModel objModel = new SiteMasterModel();
            try
            {
                dt = objDL.UpdateSite(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("DeleteSite")]
        public IHttpActionResult DeleteSite(SiteMasterModel request)
        {
            SiteMasterModel objModel = new SiteMasterModel();
            try
            {
                dt = objDL.DeleteSite(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}
