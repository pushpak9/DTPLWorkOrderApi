﻿using IMSWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Web.Http;
using System.Data;
using System.Reflection;
using System.Net.Http;
using System.Net;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using IMSWebAPI.DataLayer;
using System.Linq;

namespace IMSWebAPI.Controllers
{
    [RoutePrefix("API")]
    public class ItemMasterController : ApiController
    {
        DataTable dt = new DataTable();
        DL_ItemMaster objCust = new DL_ItemMaster();

        [HttpGet]
        [Route("GetItem")]
        public IHttpActionResult GetItemData(ItemMasterModel request)
        {
            List<ItemMasterModel> objModel = new List<ItemMasterModel>();
            try
            {
                dt = objCust.dtGetItem(request.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemMasterModel()
                            {
                                SiteCode = Convert.ToString(dr["SiteCode"]),
                                ItemCode = Convert.ToString(dr["ItemCode"]),
                                ItemDesc = Convert.ToString(dr["ItemDesc"]),
                                ItemType = Convert.ToString(dr["ItemType"]),
                                ItemMinQty = Convert.ToInt32(dr["ItemMinQty"]),
                                Brand = Convert.ToString(dr["Brand"]),
                                CreatedBy = Convert.ToString(dr["CreatedBy"])
                            }).ToList(); 
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("GetItemType")]
        public IHttpActionResult GetItemType(ItemMasterModel request)
        {
            List<ItemMasterModel> objModel = new List<ItemMasterModel>();
            try
            {
                dt = objCust.dtGetItemType(request.SiteCode);
                objModel = (from DataRow dr in dt.Rows
                            select new ItemMasterModel()
                            {
                                ItemType = Convert.ToString(dr["ItemType"]),
                            }).ToList();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Add(
                        new ItemMasterModel
                        {
                            Result = ex.Message
                        });
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("GetItemByID")]
        public IHttpActionResult GetItemByID(ItemMasterModel request)
        {
            ItemMasterModel objModel = new ItemMasterModel();
            try
            {
                dt = objCust.dtGetItemByID(request.ItemCode, request.SiteCode);
                foreach (DataRow dr in dt.Rows)
                {
                    objModel.SiteCode = Convert.ToString(dr["SiteCode"]);
                    objModel.ItemCode = Convert.ToString(dr["ItemCode"]);
                    objModel.ItemDesc = Convert.ToString(dr["ItemDesc"]);
                    objModel.ItemType = Convert.ToString(dr["ItemType"]);
                    objModel.ItemMinQty = Convert.ToInt32(dr["ItemMinQty"]);
                    objModel.Brand = Convert.ToString(dr["Brand"]);
                    objModel.CreatedBy = Convert.ToString(dr["CreatedBy"]);
                    objModel.Result = "";
                }
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpGet]
        [Route("SaveItem")]
        public IHttpActionResult SaveItem(ItemMasterModel request)
        {
            ItemMasterModel objModel = new ItemMasterModel();
            try
            {
                dt = objCust.SaveItem(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("UpdateItem")]
        public IHttpActionResult UpdateItem(ItemMasterModel request)
        {
            ItemMasterModel objModel = new ItemMasterModel();
            try
            {
                dt = objCust.UpdateItem(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }

        [HttpPost]
        [Route("DeleteItem")]
        public IHttpActionResult DeleteItem(ItemMasterModel request)
        {
            ItemMasterModel objModel = new ItemMasterModel();
            try
            {
                dt = objCust.DeleteItem(request);
                objModel.Result = dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                Common.objLogs.WriteLog(ex.Message, DTPLLogs.DTPLLogsWrite.LogType.Error, MethodBase.GetCurrentMethod());
                objModel.Result = ex.Message;
            }
            return Json(objModel);
        }
    }
}
